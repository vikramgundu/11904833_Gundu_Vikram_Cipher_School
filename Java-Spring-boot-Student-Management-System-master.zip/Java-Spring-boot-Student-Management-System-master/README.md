# Java-Spring-boot-Student-Management-System

Command-line Instructions

Prerequisites:

•	Install the latest version of Java and Maven.


Eclipse Instructions

Prerequisites:

•	Install Eclipse, the Maven plugin, and optionally the GitHub plugin.
•	Set up Eclipse Preferences

•	Window > Preferences... (or on Mac, Eclipse > Preferences...)

Select Maven

•	check on "Download Artifact Sources"
•	check on "Download Artifact JavaDoc"



Run

•	Right-click on project
•	Run As > Java Application
•	If asked, type "student-management-system" and click OK

Database
•	MongoDB
  

