package com.studentmgr.service;

import com.studentmgr.common.service.GenericService;
import com.studentmgr.model.Student;

public interface StudentService extends GenericService<Student>{
	
}
