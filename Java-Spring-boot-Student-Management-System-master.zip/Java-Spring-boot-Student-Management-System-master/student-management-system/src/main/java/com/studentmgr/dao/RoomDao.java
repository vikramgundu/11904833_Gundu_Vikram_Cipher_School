package com.studentmgr.dao;

import com.studentmgr.common.dao.GenericDao;
import com.studentmgr.model.Room;

public interface RoomDao extends GenericDao<Room>{
}
