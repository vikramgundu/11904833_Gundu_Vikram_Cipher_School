package com.studentmgr.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfiguration {
}
