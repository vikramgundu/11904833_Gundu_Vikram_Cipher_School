package com.studentmgr.dao;

import com.studentmgr.common.dao.GenericDao;
import com.studentmgr.model.Meeting;

public interface MeetingDao extends GenericDao<Meeting>{
}
