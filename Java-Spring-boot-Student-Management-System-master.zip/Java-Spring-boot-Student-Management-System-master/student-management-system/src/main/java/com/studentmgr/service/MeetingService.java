package com.studentmgr.service;

import com.studentmgr.common.service.GenericService;
import com.studentmgr.model.Meeting;

public interface MeetingService extends GenericService<Meeting>{
	
}
