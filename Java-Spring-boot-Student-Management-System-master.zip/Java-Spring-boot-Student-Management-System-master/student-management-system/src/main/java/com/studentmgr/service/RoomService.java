package com.studentmgr.service;

import com.studentmgr.common.service.GenericService;
import com.studentmgr.model.Room;

public interface RoomService extends GenericService<Room>{
	
}
