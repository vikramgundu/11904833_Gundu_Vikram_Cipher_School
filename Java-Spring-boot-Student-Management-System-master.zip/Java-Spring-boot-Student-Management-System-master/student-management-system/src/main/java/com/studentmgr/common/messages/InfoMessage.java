package com.studentmgr.common.messages;

public class InfoMessage {
}
